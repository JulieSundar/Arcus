var geolocation1 = new AR.GeoLocation(47.77317, 13.069929);
var altitude = location1.altitude; //altitude = -32768
var geolocation2 = new AR.GeoLocation(47.77317, 13.069929, 320.);
altitude = location2.altitude; //alt = 320
var object1 = new AR.GeoObject(location1);
var object2 = new AR.GeoObject(location2);

// a GeoObject which is disabled per default
var geoObject1 = new AR.GeoObject(geoLocation1, {
  enabled : false
});
// now, we enable geoObject1 so it will is considered for projection.
geoObject1.enabled = true;


// a GeoObject which reacts when the GeoObject becomes visible and invisible.
// whenever it becomes visible, the altitude is increased by 1 meter
// whenever it becomes invisible, the altitude decreases by 1 meter.
var geoObject2 = new AR.GeoObject(geoLocation1);
geoObject2.onEnterFieldOfVision = function() {
  geoObject2.locations[0].altitude++;
};
geoObject2.onExitFieldOfVision = function() {
  geoObject2.locations[0].altitude--;
};


// a GeoObject which has two locations set
var geoObject3 = new AR.GeoObject( [ geoLocation1, geoLocation2 ], null);


// a GeoObject with triggers and drawables set on creation date 
var geoObject4 = new AR.GeoObject(locations, {
  //the function executed when the GeoObject enters the field of vision
  onEnterFieldOfVision : function(){ ... },
  //the function executed when the GeoObject exits the field of vision
  onExitFieldOfVision : function(){ ... },
  drawables : { cam :
      [drawable1, drawable2] //the drawables representing the GeoObject in the camera view
  }
});


//The Drawables can also be specified as a single object:
new AR.GeoObject(locations,
  { ...
    drawables : { cam : drawable1}
  }
);