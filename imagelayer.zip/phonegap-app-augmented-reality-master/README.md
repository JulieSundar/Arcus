# PhoneGap Day Wikitude AR Demo
Simply launch this project through the PhoneGap Developer App (1.7.0 and higher) and
camera over the PhoneGap Day EU T-Shirt to see a cool demo!

